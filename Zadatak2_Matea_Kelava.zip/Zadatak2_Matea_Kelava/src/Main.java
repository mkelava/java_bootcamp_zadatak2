import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double kilometri;
        try {
            System.out.print("Unesite broj kilometara: ");
            kilometri = sc.nextDouble();
            if (kilometri < 0) {
                throw new IllegalArgumentException("Broj kilometara ne može biti negativan!");
            }
        } catch (Exception e) {
            System.out.println("Upozorenje: " + e.getMessage());
            return;
        }

        double konverzijskiFaktor;
        try {
            System.out.print("Unesite konverzijski faktor: ");
            konverzijskiFaktor = sc.nextDouble();
            if (konverzijskiFaktor < 0) {
                throw new IllegalArgumentException("Konverzijski faktor ne može biti negativan!");
            }
        } catch (Exception e) {
            System.out.println("Upozorenje: " + e.getMessage());
            return;
        }

        int milje = (int) Math.round(kilometri / konverzijskiFaktor);


        try {
            File file = new File("konverzijski_faktor.txt");
            FileWriter writer = new FileWriter(file);
            writer.write(Double.toString(konverzijskiFaktor));
            writer.close();
        } catch (IOException e) {
            System.out.println("Pogreška: " + e.getMessage());
            return;
        }

        double procitaniKonverzijskiFaktor;
        try {
            File file = new File("konverzijski_faktor.txt");
            Scanner fileScanner = new Scanner(file);
            procitaniKonverzijskiFaktor = Double.parseDouble(fileScanner.nextLine());
            fileScanner.close();
            if (konverzijskiFaktor != procitaniKonverzijskiFaktor) {
                throw new IllegalArgumentException("Uneseni konverzijski faktor nije jednak pročitanom konverzijskom faktoru!");
            }
        } catch (Exception e) {
            System.out.println("Upozorenje: " + e.getMessage());
            return;
        }

        System.out.println("Iz datoteke: konverzijskiFaktor = " +procitaniKonverzijskiFaktor);
        System.out.println("Uneseno je " + kilometri + " kilometara, što je " + milje + " milja");
    }
}

